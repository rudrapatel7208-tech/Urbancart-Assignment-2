CREATE DATABASE IF NOT EXISTS urbancart CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE urbancart;
CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),email VARCHAR(150) UNIQUE,mobile VARCHAR(20),password VARCHAR(255),address TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE categories(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),description VARCHAR(255),icon VARCHAR(20),status TINYINT DEFAULT 1);
CREATE TABLE products(id INT AUTO_INCREMENT PRIMARY KEY,category_id INT,name VARCHAR(150),price DECIMAL(10,2),description TEXT,stock INT DEFAULT 0,emoji VARCHAR(20),status TINYINT DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE CASCADE);
CREATE TABLE orders(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,total DECIMAL(10,2),payment_method VARCHAR(50),status VARCHAR(30),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE order_items(id INT AUTO_INCREMENT PRIMARY KEY,order_id INT,product_id INT,quantity INT,price DECIMAL(10,2),FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,FOREIGN KEY(product_id) REFERENCES products(id));
CREATE TABLE messages(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),email VARCHAR(150),message TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
INSERT INTO categories(name,description,icon) VALUES
('Clothing','Everyday shirts, tees and fashion.','👕'),('Footwear','Sneakers and comfortable shoes.','👟'),('Accessories','Finish your look with style.','👜'),('Streetwear','Fresh urban styles and essentials.','🧢');
INSERT INTO products(category_id,name,price,description,stock,emoji) VALUES
(1,'Classic Oversized Tee',899,'Soft cotton oversized t-shirt for everyday comfort.',30,'👕'),
(1,'Minimal Hoodie',1799,'Clean premium hoodie with a relaxed fit.',25,'🧥'),
(2,'Urban Runner Sneakers',2499,'Lightweight sneakers designed for daily wear.',18,'👟'),
(2,'Classic Casual Shoes',2199,'Smart casual shoes for college and outings.',20,'🥾'),
(3,'Everyday Crossbody Bag',1299,'Compact crossbody bag with modern styling.',15,'👜'),
(3,'Classic Watch',1599,'Minimal dial watch for a clean look.',12,'⌚'),
(4,'Street Cap',699,'Adjustable cap with a simple urban design.',40,'🧢'),
(4,'Cargo Joggers',1899,'Comfortable utility joggers with multiple pockets.',22,'👖');
