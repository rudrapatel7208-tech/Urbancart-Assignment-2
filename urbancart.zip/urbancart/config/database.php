<?php
session_start();
$host="localhost"; $db="urbancart"; $user="root"; $pass="";
try{$pdo=new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}
catch(PDOException $e){die("Database connection failed. Import database/urbancart.sql in phpMyAdmin first.");}
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?>