<?php
require 'config/database.php';

if (empty($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

if (empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit;
}

$cart = $_SESSION['cart'];
$ids = implode(',', array_map('intval', array_keys($cart)));

$items = $pdo->query("SELECT * FROM products WHERE id IN ($ids)")->fetchAll();

$total = 0;

foreach ($items as $p) {
    $total += $p['price'] * $cart[$p['id']];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $s = $pdo->prepare(
        "INSERT INTO orders (user_id, total, payment_method, status)
         VALUES (?, ?, ?, ?)"
    );

    $s->execute([
        $_SESSION['user']['id'],
        $total,
        $_POST['payment'],
        'Pending'
    ]);

    $oid = $pdo->lastInsertId();

    foreach ($items as $p) {

        $q = $pdo->prepare(
            "INSERT INTO order_items (order_id, product_id, quantity, price)
             VALUES (?, ?, ?, ?)"
        );

        $q->execute([
            $oid,
            $p['id'],
            $cart[$p['id']],
            $p['price']
        ]);

        $pdo->prepare(
            "UPDATE products SET stock = stock - ? WHERE id = ?"
        )->execute([
            $cart[$p['id']],
            $p['id']
        ]);
    }

    $_SESSION['cart'] = [];

    header("Location: order-success.php?id=$oid");
    exit;
}

include 'includes/header.php';
?>

<div class="page">
    <h1>Checkout</h1>

    <form class="form" method="post">

        <input
            name="name"
            value="<?= e($_SESSION['user']['name']) ?>"
            placeholder="Customer Name"
            required
        >

        <input
            name="mobile"
            value="<?= e($_SESSION['user']['mobile']) ?>"
            placeholder="Mobile"
            required
        >

        <textarea
            name="address"
            placeholder="Shipping Address"
            required
        ><?= e($_SESSION['user']['address']) ?></textarea>

        <input
            name="city"
            placeholder="City"
            required
        >

        <input
            name="state"
            placeholder="State"
            required
        >

        <input
            name="pincode"
            placeholder="Pincode"
            required
        >

        <label>Payment Method</label>

        <select name="payment">
            <option>Cash on Delivery</option>
        </select>

        <h2>Total: ₹<?= number_format($total) ?></h2>

        <button class="btn" type="submit">
            Place Order
        </button>

    </form>
</div>

<?php include 'includes/footer.php'; ?>